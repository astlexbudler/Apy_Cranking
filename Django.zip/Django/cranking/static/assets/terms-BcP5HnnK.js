import{j as e,q as t,P as s,T as a,H as u,C as n}from"./index-OSHjpEom.js";import{S as l}from"./section-title-DXBIhfo3.js";function r(){const i=e.jsx(s,{variant:"outlined",sx:{p:2,maxHeight:500,overflow:"auto"},children:e.jsx(a,{variant:"body2",sx:{whiteSpace:"pre-line",textAlign:"left"},children:`Donec mi odio, faucibus at, scelerisque quis, convallis in, nisi. Quisque ut nisi.
Suspendisse nisl elit, rhoncus eget, elementum ac, condimentum eget, diam. Vestibulum eu
odio. Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Cras ultricies mi eu
turpis hendrerit fringilla. Phasellus consectetuer vestibulum elit. Phasellus magna.
Nullam tincidunt adipiscing enim. Vestibulum volutpat pretium libero. Nullam quis ante.
Morbi mollis tellus ac sapien. Donec orci lectus, aliquam ut, faucibus non, euismod id,
nulla. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac
turpis egestas. Fusce ac felis sit amet ligula pharetra condimentum. Morbi mattis
ullamcorper velit. Vivamus consectetuer hendrerit lacus. Nullam quis ante. Praesent
turpis. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a
pretium mi sem ut ipsum. Donec mi odio, faucibus at, scelerisque quis, convallis in, nisi...`})});return e.jsxs(t,{sx:{textAlign:"left"},children:[e.jsx(l,{title:"이용약관 및 개인정보 처리 방침",description:"서비스 이용을 위해 아래 내용을 확인해주세요."}),i]})}const o={title:`${n.appName}`};function p(){return e.jsxs(e.Fragment,{children:[e.jsx(u,{children:e.jsxs("title",{children:[" ",o.title]})}),e.jsx(r,{})]})}export{p as default};
